<?php
    $to      = 'biaz.mohamed@gmail.com';
    $subject = 'Message de ';
    $message = "lkjklj"" ;
    $headers = "kljklj"
    mail($to, $subject, $message, $headers);
?>
